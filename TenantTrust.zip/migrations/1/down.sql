
DROP TABLE reviews;
DROP TABLE properties;
DROP TABLE users;
